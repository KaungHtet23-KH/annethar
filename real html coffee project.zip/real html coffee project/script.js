document.addEventListener('DOMContentLoaded', () => {
    // Mobile Menu Toggle
    const menuBtn = document.getElementById('menu-toggle');
    const mobileMenu = document.getElementById('mobile-menu');

    if (menuBtn && mobileMenu) {
        menuBtn.addEventListener('click', () => {
            mobileMenu.classList.toggle('active');
        });
    }

    // Cart Logic
    let cart = JSON.parse(localStorage.getItem('coffee-cart')) || [];
    const cartCountElements = document.querySelectorAll('.cart-count');

    const updateCartUI = () => {
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        cartCountElements.forEach(el => {
            el.textContent = totalItems;
            el.style.display = totalItems > 0 ? 'inline-block' : 'none';
        });
        localStorage.setItem('coffee-cart', JSON.stringify(cart));
    };

    const addToCart = (name, price) => {
        const existingItem = cart.find(item => item.name === name);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ name, price, quantity: 1 });
        }
        updateCartUI();

        // Simple feedback
        const toast = document.createElement('div');
        toast.className = 'fixed bottom-4 right-4 bg-coffee-gold text-coffee-dark px-6 py-3 rounded shadow-lg z-50 transform translate-y-0 transition-transform';
        toast.textContent = `${name} added to cart!`;
        document.body.appendChild(toast);
        setTimeout(() => {
            toast.style.transform = 'translate-y-20';
            setTimeout(() => toast.remove(), 300);
        }, 2000);
    };

    // Attach to all "Add to Cart" buttons
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', (e) => {
            const name = e.target.dataset.name;
            const price = parseFloat(e.target.dataset.price);
            addToCart(name, price);
        });
    });

    // Initialize UI
    updateCartUI();

    // Cart Page Specific Logic
    const cartTableBody = document.getElementById('cart-items');
    const cartTotalElement = document.getElementById('cart-total');

    if (cartTableBody) {
        const renderCart = () => {
            cartTableBody.innerHTML = '';
            let total = 0;

            if (cart.length === 0) {
                cartTableBody.innerHTML = '<tr><td colspan="4" class="py-8 text-center text-gray-500 italic">Your cart is empty</td></tr>';
            } else {
                cart.forEach((item, index) => {
                    const itemTotal = item.price * item.quantity;
                    total += itemTotal;

                    const row = document.createElement('tr');
                    row.className = 'border-b border-gray-800';
                    row.innerHTML = `
                        <td class="py-4">
                            <div class="font-semibold">${item.name}</div>
                        </td>
                        <td class="py-4">$${item.price.toFixed(2)}</td>
                        <td class="py-4">
                            <div class="flex items-center space-x-3">
                                <button class="update-qty text-gray-400 hover:text-white" data-index="${index}" data-delta="-1">-</button>
                                <span>${item.quantity}</span>
                                <button class="update-qty text-gray-400 hover:text-white" data-index="${index}" data-delta="1">+</button>
                            </div>
                        </td>
                        <td class="py-4 text-right">$${itemTotal.toFixed(2)}</td>
                    `;
                    cartTableBody.appendChild(row);
                });
            }
            cartTotalElement.textContent = `$${total.toFixed(2)}`;
        };

        cartTableBody.addEventListener('click', (e) => {
            if (e.target.classList.contains('update-qty')) {
                const index = parseInt(e.target.dataset.index);
                const delta = parseInt(e.target.dataset.delta);

                cart[index].quantity += delta;
                if (cart[index].quantity <= 0) {
                    cart.splice(index, 1);
                }
                updateCartUI();
                renderCart();
            }
        });

        renderCart();
    }

    // Reservation Page Logic
    const tableSelect = document.getElementById('table-select');
    const tableCards = document.querySelectorAll('.table-card');
    const reservationForm = document.getElementById('reservation-form');
    const bookingModal = document.getElementById('booking-modal');
    const closeModalBtn = document.getElementById('close-modal');
    const confirmBookingBtn = document.getElementById('confirm-booking');
    const modalDetails = document.getElementById('modal-details');

    if (reservationForm && tableSelect && tableCards.length > 0) {
        // Sync Dropdown -> Cards
        tableSelect.addEventListener('change', () => {
            const selectedValue = tableSelect.value;
            tableCards.forEach(card => {
                if (card.dataset.table === selectedValue) {
                    card.classList.add('selected');
                    card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                } else {
                    card.classList.remove('selected');
                }
            });
        });

        // Sync Cards -> Dropdown
        tableCards.forEach(card => {
            card.addEventListener('click', () => {
                const tableValue = card.dataset.table;
                tableSelect.value = tableValue;

                // Trigger change highlight
                tableCards.forEach(c => c.classList.remove('selected'));
                card.classList.add('selected');
            });
        });

        // Form Submission -> Modal
        reservationForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const formData = new FormData(reservationForm);
            const date = reservationForm.querySelector('input[type="date"]').value;
            const time = reservationForm.querySelector('input[type="time"]').value;
            const guests = reservationForm.querySelector('input[type="number"]').value;
            const tableName = tableSelect.options[tableSelect.selectedIndex].text;

            modalDetails.innerHTML = `
                <div class="flex justify-between"><span class="text-gray-500">Table:</span> <span class="text-coffee-gold font-semibold">${tableName}</span></div>
                <div class="flex justify-between"><span class="text-gray-500">Date:</span> <span class="text-white">${date}</span></div>
                <div class="flex justify-between"><span class="text-gray-500">Time:</span> <span class="text-white">${time}</span></div>
                <div class="flex justify-between"><span class="text-gray-500">Guests:</span> <span class="text-white">${guests} People</span></div>
            `;

            bookingModal.classList.remove('hidden');
        });

        // Close Modal
        closeModalBtn.addEventListener('click', () => {
            bookingModal.classList.add('hidden');
        });

        // Confirm Booking
        confirmBookingBtn.addEventListener('click', () => {
            alert('Reservation Confirmed! We have sent a confirmation email.');
            bookingModal.classList.add('hidden');
            reservationForm.reset();
            tableCards.forEach(c => c.classList.remove('selected'));
        });

        // Close on backdrop click
        bookingModal.addEventListener('click', (e) => {
            if (e.target === bookingModal) {
                bookingModal.classList.add('hidden');
            }
        });
    }
});
